import React, { Component } from 'react';
import {Link} from 'react-router-dom';
import Papa from 'papaparse';
import './index.css';

class ExamSeating extends Component {
  state = {
    // Files and parsed students
    file: null,
    file2: null,
    students: [],
    students2: [],
    // Room data and selection
    rooms: [],
    selectedRooms: [],
    roomsTotalSeats: 0,
    // Exam and branch info
    examDatetime: '',
    branch: '',       // Used in single file mode (comma separated)
    branch1: '',      // Used in double file mode (for file1)
    branch2: '',      // Used in double file mode (for file2)
    // Allotment map (room_number: 2D seating arrangement)
    allotment: {},
    error: '',
    apiRoomStatus: 'inpro',
    // New options:
    allotmentDirection: 'row',    // Options: "row", "column", "checkerboard"
    uploadMode: 'single',         // Options: "single", "double"
  };

  componentDidMount() {
    this.fetchRooms();
  }

  fetchRooms = async () => {
    try {
      const response = await fetch('/api/rooms');
      const data = await response.json();
      if (response.ok) {
        this.setState({ rooms: data.data, apiRoomStatus: 'suc' });
      } else {
        throw new Error(data.message || 'Failed to fetch rooms');
      }
    } catch (error) {
      this.setState({ error: error.message });
    }
  };

  // Handle file changes for single upload
  handleFileChange = (e) => {
    this.setState({ file: e.target.files[0] });
  };

  // Handle file changes for second file in double mode
  handleFileChange2 = (e) => {
    this.setState({ file2: e.target.files[0] });
  };

  // Parse CSV for file1
  // Parse CSV for file1 using the "rollno" header
handleFileUpload = () => {
  const { file } = this.state;
  if (file) {
    Papa.parse(file, {
      header: true,  // Parse the CSV using the header row as keys
      complete: (result) => {
        // Map each row's "rollno" property and filter out any empty values.
        const students = result.data
          .map((row) => row.rollno)
          .filter((roll) => roll && roll.trim() !== '');
        console.log("Parsed Students (File 1):", students);
        this.setState({ students });
      },
      error: (error) => {
        this.setState({ error: error.message });
      }
    });
  }
};

// Parse CSV for file2 (for double mode) using the "rollno" header
handleFileUpload2 = () => {
  const { file2 } = this.state;
  if (file2) {
    Papa.parse(file2, {
      header: true,
      complete: (result) => {
        const students2 = result.data
          .map((row) => row.rollno)
          .filter((roll) => roll && roll.trim() !== '');
        console.log("Parsed Students (File 2):", students2);
        this.setState({ students2 });
      },
      error: (error) => {
        this.setState({ error: error.message });
      }
    });
  }
};


  handleRoomSelect = (e) => {
    const { rooms, selectedRooms } = this.state;
    const selectedRoomNo = e.target.value;
    const selectedRoom = rooms.find((room) => room.room_number === selectedRoomNo);
    if (!selectedRoom) return;
    const seatsAvailable = selectedRoom.rows * selectedRoom.columns;
    if (!e.target.checked) {
      const updatedRooms = selectedRooms.filter((rm) => rm.room_number !== selectedRoomNo);
      this.setState((prevState) => ({
        selectedRooms: updatedRooms,
        roomsTotalSeats: prevState.roomsTotalSeats - seatsAvailable,
      }));
    } else {
      this.setState((prevState) => ({
        selectedRooms: [...prevState.selectedRooms, selectedRoom],
        roomsTotalSeats: prevState.roomsTotalSeats + seatsAvailable,
      }));
    }
  };

  // Helper: Merge two arrays alternately (used for non-checkerboard in double mode)
  mergeAlternating = (arr1, arr2) => {
    const maxLength = Math.max(arr1.length, arr2.length);
    const merged = [];
    for (let i = 0; i < maxLength; i++) {
      if (i < arr1.length) merged.push(arr1[i]);
      if (i < arr2.length) merged.push(arr2[i]);
    }
    return merged;
  };

  createAllotment = () => {
    const { selectedRooms, allotmentDirection, uploadMode, students, students2 } = this.state;
    let newAllotment = {};
  
    if (allotmentDirection === "checkerboard") {
      // Global indices for checkerboard mode
      let globalIndex1 = 0;
      let globalIndex2 = 0;
      selectedRooms.forEach((room) => {
        const { rows, columns, room_number, unavialable_positions = [] } = room;
        // Create empty seating grid
        let roomSeats = Array.from({ length: rows }, () => Array(columns).fill(null));
  
        for (let i = 0; i < rows; i++) {
          for (let j = 0; j < columns; j++) {
            if (unavialable_positions.some((pos) => pos.row === i + 1 && pos.column === j + 1)) {
              roomSeats[i][j] = null;
            } else {
              // Checkerboard pattern: even (i+j) -> branch1, odd -> branch2.
              if ((i + j) % 2 === 0) {
                if (globalIndex1 < students.length) {
                  roomSeats[i][j] = students[globalIndex1++];
                } else if (globalIndex2 < students2.length) {
                  roomSeats[i][j] = students2[globalIndex2++];
                }
              } else {
                if (globalIndex2 < students2.length) {
                  roomSeats[i][j] = students2[globalIndex2++];
                } else if (globalIndex1 < students.length) {
                  roomSeats[i][j] = students[globalIndex1++];
                }
              }
            }
          }
        }
        newAllotment[room_number] = roomSeats;
      });
    } else {
      // For row or column allotment
      let studentArray =
        uploadMode === "double"
          ? this.mergeAlternating(students, students2)
          : students;
      let globalIndex = 0;
  
      selectedRooms.forEach((room) => {
        const { rows, columns, room_number, unavialable_positions = [] } = room;
        let roomSeats = Array.from({ length: rows }, () => Array(columns).fill(null));
  
        if (allotmentDirection === "row") {
          for (let i = 0; i < rows; i++) {
            for (let j = 0; j < columns; j++) {
              if (unavialable_positions.some((pos) => pos.row === i + 1 && pos.column === j + 1)) {
                roomSeats[i][j] = null;
              } else if (globalIndex < studentArray.length) {
                roomSeats[i][j] = studentArray[globalIndex++];
              }
            }
          }
        } else if (allotmentDirection === "column") {
          for (let j = 0; j < columns; j++) {
            for (let i = 0; i < rows; i++) {
              if (unavialable_positions.some((pos) => pos.row === i + 1 && pos.column === j + 1)) {
                roomSeats[i][j] = null;
              } else if (globalIndex < studentArray.length) {
                roomSeats[i][j] = studentArray[globalIndex++];
              }
            }
          }
        }
        newAllotment[room_number] = roomSeats;
      });
    }
    
    console.log("Generated Allotment:", newAllotment);
    this.setState({ allotment: newAllotment });
  };
  
  handleSubmit = async () => {
    const { examDatetime, branch, branch1, branch2, selectedRooms, allotment, uploadMode } = this.state;
    
    if (!examDatetime || 
        (uploadMode === "single" && !branch) || 
        (uploadMode === "double" && (!branch1 || !branch2)) || 
        selectedRooms.length === 0 || 
        Object.keys(allotment).length === 0) {
      this.setState({ error: 'Missing required fields.' });
      return;
    }
    
    // Determine branch array based on upload mode
    const students_branches = uploadMode === "double" 
      ? [branch1.trim(), branch2.trim()] 
      : branch.split(',').map(b => b.trim());
    
    const roomNumbers = selectedRooms.map(room => room.room_number);
    const localDate = new Date(examDatetime);
    const correctedDate = new Date(localDate.getTime() - localDate.getTimezoneOffset() * 60000);

    const payload = {
      exam_datetime: correctedDate,
      students_branches,
      room_no: roomNumbers,
      allotment: {},
      unavialable_positions: {}
    };
  
    // For each selected room, add its seating allotment and unavailable positions
    selectedRooms.forEach(room => {
      const rn = room.room_number;
      payload.allotment[rn] = allotment[rn] || [];
      payload.unavialable_positions[rn] = room.unavialable_positions || [];
    });
  
    try {
      const response = await fetch('/api/allotments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      
      if (!response.ok) {
        throw new Error('Failed to submit allotment');
      }
      
      const resData = await response.json();
      console.log('Allotment successful:', resData);
    } catch (error) {
      this.setState({ error: error.message });
    }
  };

  renderRooms = () => {
    const { rooms } = this.state;
    return (
      <div>
        <h1>Select Room:</h1>
        <ul className="room-list">
          {rooms.map((room) => (
            <li key={room._id} className="room-item">
              <input id={room._id} value={room.room_number} type="checkbox" onChange={this.handleRoomSelect} />
              <label htmlFor={room._id}>{room.room_number} ({room.building_name})</label>
              <p>Total Seats: {room.rows * room.columns}</p>
            </li>
          ))}
        </ul>
      </div>
    );
  };
  renderNav = ()=>{
    return (<div className="homeNavBar">
        <img src="../../images/jntuaceatp.webp" alt="jntua-img" className='navLogo'/>
        <ul type="none" className='navElements'>
            <Link to="/" className='custom-link'><li>Home</li></Link>
            <Link to="/rooms" className='custom-link'><li>Rooms</li></Link>
            <Link to="/examseating" className='custom-link'><li>Allotment</li></Link>
            <li>Login</li>
        </ul>
    </div>)
}
  render() {
    const { students, allotment, error, examDatetime, branch, branch1, branch2, apiRoomStatus, selectedRooms, allotmentDirection, uploadMode } = this.state;
    console.log("Selected Rooms:", selectedRooms);
    return (
      <>
      <div>
          {this.renderNav()}
        </div>
      <div className="container">
        <h2 className="header">Exam Seating Arrangement</h2>
        {error && <p className="error">{error}</p>}
        
        {/* Upload Mode Selection */}
        <div className="section upload-mode">
          <h3>Select Upload Mode:</h3>
          <label>
            <input 
              type="radio" 
              name="uploadMode" 
              value="single" 
              checked={uploadMode === "single"} 
              onChange={(e) => this.setState({ uploadMode: e.target.value })}
            /> Single File
          </label>
          <label>
            <input 
              type="radio" 
              name="uploadMode" 
              value="double" 
              checked={uploadMode === "double"} 
              onChange={(e) => this.setState({ uploadMode: e.target.value })}
            /> Two Files
          </label>
        </div>
        
        {/* File Upload Section */}
        <div className="section file-upload">
          <h3>Upload CSV File{uploadMode === "double" ? "s" : ""}</h3>
          {uploadMode === "single" ? (
            <>
              <input type="file" accept=".csv" onChange={this.handleFileChange} />
              <button className="btn" onClick={this.handleFileUpload}>Upload</button>
            </>
          ) : (
            <>
              <div>
                <label>File for Branch 1:</label>
                <input type="file" accept=".csv" onChange={this.handleFileChange} />
                <button className="btn" onClick={this.handleFileUpload}>Upload Branch 1</button>
              </div>
              <div>
                <label>File for Branch 2:</label>
                <input type="file" accept=".csv" onChange={this.handleFileChange2} />
                <button className="btn" onClick={this.handleFileUpload2}>Upload Branch 2</button>
              </div>
            </>
          )}
        </div>
        
        {/* Branch Input */}
        {uploadMode === "double" ? (
          <div className="section">
            <label className="input-field">
              Branch for File 1:
              <input type="text" value={branch1} onChange={(e) => this.setState({ branch1: e.target.value })} placeholder="e.g. CSE" />
            </label>
            <label className="input-field">
              Branch for File 2:
              <input type="text" value={branch2} onChange={(e) => this.setState({ branch2: e.target.value })} placeholder="e.g. ECE" />
            </label>
          </div>
        ) : (
          <div className="section">
            <label className="input-field">
              Student Branches (comma separated):
              <input type="text" value={branch} onChange={(e) => this.setState({ branch: e.target.value })} placeholder="e.g. CSE,ECE" />
            </label>
          </div>
        )}
        
        {/* Exam Date & Time */}
        <div className="section">
          <label className="input-field">
            Exam Date & Time:
            <input type="datetime-local" value={examDatetime} onChange={(e) => this.setState({ examDatetime: e.target.value })} />
          </label>
        </div>
        
        {/* Allotment Direction Selection */}
        <div className="section allotment-type">
          <h3>Select Allotment Direction:</h3>
          <label>
            <input 
              type="radio" 
              name="allotmentDirection" 
              value="row" 
              checked={allotmentDirection === "row"} 
              onChange={(e) => this.setState({ allotmentDirection: e.target.value })}
            /> Row-wise
          </label>
          <label>
            <input 
              type="radio" 
              name="allotmentDirection" 
              value="column" 
              checked={allotmentDirection === "column"} 
              onChange={(e) => this.setState({ allotmentDirection: e.target.value })}
            /> Column-wise
          </label>
          {uploadMode === "double" && (
            <label>
              <input 
                type="radio" 
                name="allotmentDirection" 
                value="checkerboard" 
                checked={allotmentDirection === "checkerboard"} 
                onChange={(e) => this.setState({ allotmentDirection: e.target.value })}
              /> Checkerboard (Alternate Branch)
            </label>
          )}
        </div>
        
        {apiRoomStatus && <>{this.renderRooms()}</>}
        
        <div className="section">
          <button className="btn generate" onClick={this.createAllotment}>Generate Allotment</button>
        </div>
        
        <div className="section allotment-preview">
          <h3>Allotment Preview</h3>
          <pre>{JSON.stringify(allotment, null, 2)}</pre>
        </div>
        
        <div className="section">
          <button className="btn submit" onClick={this.handleSubmit}>Submit Allotment</button>
        </div>
      </div>
      <Link to="/" className="room-item-p"><button>Back</button></Link>
      </>
    );
  }
}

export default ExamSeating;
