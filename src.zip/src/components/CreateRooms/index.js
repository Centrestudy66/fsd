import { Component } from 'react';
import {Link} from 'react-router-dom';
import './CreateRooms.css';

class CreateRooms extends Component {
  state = {
    availableRooms: [],
    apiRoomStatus: 'inpro',
    apiUploadRoomStatus: '',
    error: '',
    room_number: "",
    rows: 0,
    columns: 0,
    building_name: "",
    unavailable_positions: [
      { row: 0, column: 0 },
      { row: 0, column: 0 },
    ],
  };

  componentDidMount() {
    this.fetchRooms();
  }

  fetchRooms = async () => {
    try {
      const response = await fetch('/api/rooms');
      const data = await response.json();
      if (response.ok) {
        this.setState({ availableRooms: data.data, apiRoomStatus: 'suc' });
      } else {
        throw new Error(data.message || 'Failed to fetch rooms');
      }
    } catch (error) {
      this.setState({ error: error.message });
    }
  };

  handleChange = (e) => {
    const { name, value } = e.target;
    this.setState({ [name]: value });
  };

  handlePositionChange = (index, field, value) => {
    const updatedPositions = this.state.unavailable_positions.map((pos, i) =>
      i === index ? { ...pos, [field]: value } : pos
    );
    this.setState({ unavailable_positions: updatedPositions });
  };

  addPosition = () => {
    this.setState((prevState) => ({
      unavailable_positions: [...prevState.unavailable_positions, { row: "", column: "" }],
    }));
  };

  removePosition = (index) => {
    this.setState((prevState) => ({
      unavailable_positions: prevState.unavailable_positions.filter((_, i) => i !== index),
    }));
  };

  handleSubmit = async (e) => {
    e.preventDefault();
    const { room_number, rows, columns, building_name, unavailable_positions } = this.state;
    const payload = { room_number, rows, columns, building_name, unavailable_positions };

    try {
      const response = await fetch("/api/rooms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      console.log(response)
      if (response.ok) {
        alert("Room data submitted successfully!");
      } else {
        alert("Failed to submit data");
      }
    } catch (error) {
      console.error("Error submitting data:", error);
    }
  };

  renderFormCreateRooms = () => {
    const { room_number, rows, columns, building_name, unavailable_positions } = this.state;
    return (
        <>
        <h1>Create Room:</h1>
      <form onSubmit={this.handleSubmit} className="room-form">
        <label>Room Number</label>
        <input name="room_number" value={room_number} onChange={this.handleChange} required />

        <label>Rows</label>
        <input type="number" name="rows" value={rows} onChange={this.handleChange} required />

        <label>Columns</label>
        <input type="number" name="columns" value={columns} onChange={this.handleChange} required />

        <label>Building Name</label>
        <input name="building_name" value={building_name} onChange={this.handleChange} required />

        <label>Unavailable Positions</label>
        {unavailable_positions.map((pos, index) => (
          <div key={index} className="position-container">
            <input type="number" value={pos.row} onChange={(e) => this.handlePositionChange(index, "row", e.target.value)} placeholder="Row" required />
            <input type="number" value={pos.column} onChange={(e) => this.handlePositionChange(index, "column", e.target.value)} placeholder="Column" required />
            <button type="button" onClick={() => this.removePosition(index)} className="remove-button">Remove</button>
          </div>
        ))}
        <button type="button" onClick={this.addPosition} className="add-button">Add Position</button>

        <button type="submit" className="submit-button">Submit</button>
      </form></>
    );
  };

  renderRooms = () => {
    const { availableRooms } = this.state;
    return (
      <div className="room-container">
        <h1>Available Rooms:</h1>
        <ul className="room-list">
          {availableRooms.map((room) => (
            <li key={room._id} className="room-item">
              <p className='room-item-p'>roomNo:{room.room_number} Building:({room.building_name})</p>
              <p>Number of Rows:{room.rows}</p>
              <p>Number of columns:{room.columns}</p>
              <p>Total Seats: {room.rows * room.columns}</p>
            </li>
          ))}
        </ul>
      </div>
    );
  };
  renderNav = ()=>{
    return (<div className="homeNavBar">
        <img src="../../images/jntuaceatp.webp" alt="jntua-img" className='navLogo'/>
        <ul type="none" className='navElements'>
            <Link to="/" className='custom-link'><li>Home</li></Link>
            <Link to="/rooms" className='custom-link'><li>Rooms</li></Link>
            <Link to="/examseating" className='custom-link'><li>Allotment</li></Link>
            <li>Login</li>
        </ul>
    </div>)
}
  render() {
    return (
        <>{this.renderNav()}
      <div className="main-container">
        {this.renderFormCreateRooms()}
        {this.renderRooms()}
      </div>
      <Link to="/" className="room-item-p"><button>Back</button></Link>
      </>
    );
  }
}

export default CreateRooms;
