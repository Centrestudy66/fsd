import {BrowserRouter,Routes,Route} from 'react-router-dom'
import Home from './components/Home';
import ExamSeating from './components/ExamSeating';
import CreateRooms from './components/CreateRooms';
const App = () => {
    return (
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home/>}/>
          <Route exact path="/examseating" element={<ExamSeating/>}/>
          <Route exact path="/rooms" element={<CreateRooms/>}/>
        </Routes>
      </BrowserRouter>
    )
  }

export default App;