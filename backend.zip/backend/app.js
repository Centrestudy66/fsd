const Express = require("express")

const app = Express()

const AllotmentRouter=require("./Routers/AllotmentRouter")
const RoomRouter = require("./Routers/RoomRouter")

app.use(Express.json())
app.use(Express.urlencoded({ extended: true }))

app.use("/api/rooms", RoomRouter)
app.use("/api/allotments",AllotmentRouter)

module.exports = app