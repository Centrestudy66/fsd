const { query } = require("express")
const RoomModel = require("../Modules/Room")
module.exports.getAllRooms = async (req, res) => {
    try{
    const data = await RoomModel.find()
    return res.status(200).json({ success: true, data })
    }catch(e){
        return e
    }
}
module.exports.getSingleRoom = async (req, res) => {
    try{
    const {_id}= req.params
    const data = await RoomModel.findById(_id)
    return res.status(200).json({ success: true, data })
    }catch(e){
        return e
    }
}

module.exports.createRoom = async (req, res) => {
    const bodyData = req.body
    try {
        const sport = RoomModel(bodyData)
        await sport.save()
    } catch (err) {
        console.log(err)
        return res.status(400).json({ success: false, msg: "Falied to create." })
    }
    res.status(200).json({ success: true, msg: "Successfully created Room." })
}