const { query } = require("express")
const AllotmentModel = require("../Modules/Allotment")
module.exports.getAllAllotments = async (req, res) => {
    try{
    const data = await AllotmentModel.find()
    return res.status(200).json({ success: true, data })
    }catch(e){
        return e
    }
}
module.exports.getSingleAllotment = async (req, res) => {
    try{
    const {_id}= req.params
    const data = await AllotmentModel.findById(_id)
    return res.status(200).json({ success: true, data })
    }catch(e){
        return e
    }
}

module.exports.createAllotment = async (req, res) => {
    const bodyData = req.body
    try {
        const sport = AllotmentModel(bodyData)
        await sport.save()
    } catch (err) {
        console.log(err)
        return res.status(400).json({ success: false, msg: "Falied to create." })
    }
    res.status(200).json({ success: true, msg: "Successfully created Allotment." })
}